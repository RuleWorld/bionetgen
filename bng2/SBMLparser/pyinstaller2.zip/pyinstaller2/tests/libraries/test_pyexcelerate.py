#-----------------------------------------------------------------------------
# Copyright (c) 2013, PyInstaller Development Team.
#
# Distributed under the terms of the GNU General Public License with exception
# for distributing bootloader.
#
# The full license is in the file COPYING.txt, distributed with this software.
#-----------------------------------------------------------------------------

# Requires PyExcelerate 0.6.1 or higher
# Tested on Windows 7 x64 SP1 with CPython 2.7.6

import pyexcelerate
