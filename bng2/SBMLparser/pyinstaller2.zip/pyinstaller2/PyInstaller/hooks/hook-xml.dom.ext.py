#-----------------------------------------------------------------------------
# Copyright (c) 2013, PyInstaller Development Team.
#
# Distributed under the terms of the GNU General Public License with exception
# for distributing bootloader.
#
# The full license is in the file COPYING.txt, distributed with this software.
#-----------------------------------------------------------------------------


attrs = [('Node',0),
         ('NodeFilter',0),
         ('XML_NAMESPACE',0),
         ('XMLNS_NAMESPACE',0),
         ('DOMException',0),
         ('HTML_4_TRANSITIONAL_INLINE',0),
         ('IsDOMString',0),
         ('FtDomException',0),
         ('NodeTypeDict',0),
         ('NodeTypeToClassName',0),
         ('Print',0),
         ('PrettyPrint',0),
         ('XHtmlPrettyPrint',0),
         ('XHtmlPrint',0),
         ('ReleaseNode',0),
         ('StripHtml',0),
         ('StripXml',0),
         ('GetElementById',0),
         ('XmlSpaceState',0),
         ('GetAllNs',0),
         ('SplitQName',0),
         ('SeekNss',0),
    ]
